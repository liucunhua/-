package com.sonnokta.utils;

public class Constants {
    public static boolean LOG_ENABLE = false;
}
