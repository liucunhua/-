package com.sonnokta;

import android.app.Activity;

public class p059j extends Activity {
}
