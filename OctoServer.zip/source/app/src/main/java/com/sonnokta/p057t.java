package com.sonnokta;

import android.app.Activity;

public class p057t extends Activity {
}
