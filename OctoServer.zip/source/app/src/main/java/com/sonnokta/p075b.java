package com.sonnokta;

import android.app.Activity;

public class p075b extends Activity {
}
