<?php
define('DEBUG', false);
define('MYSQL_USER', 'root');  // 修改为你的MySQL用户名
define('MYSQL_PASS', '');      // 修改为你的MySQL密码
define('MYSQL_DB_NAME', 'aok'); // 修改为你要使用的数据库名
define('PANEL_FOLDER', 'maincp');
define('STATS_FOLDER', 'stats');
define('MAIN_FOLDER', 'root');

define('PHP_LOG_PATH', 'php_error.log');
define('APACHE_LOG_PATH', 'apache_error.log');
