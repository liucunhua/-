<?php 
$kul[0]['username']="admin"; 
$kul[0]['password']="admin"; 


function authenticate() 
{ 
header( 'WWW-Authenticate: Basic realm="Connected"' ); 
header( 'HTTP/1.0 401 Unauthorized' ); 
exit; 
} 

if (!isset($_SERVER['PHP_AUTH_USER']) || !isset($_SERVER['PHP_AUTH_PW'])) { authenticate(); } else 
{ 
for($i=0;$i<count($kul);$i++) { if($_SERVER['PHP_AUTH_USER']==$kul[$i]['username'] && $_SERVER['PHP_AUTH_PW']==$kul[$i]['password']){$auth=TRUE;}} 
if($auth !=TRUE) {authenticate();} 
} 
?>
<?php

if(file_exists("install.php")) die("<p style='margin-top: 100px; text-align: center; color: red'>请重命名或删除 install.php 文件</p>");

if(!is_writable("../data/")) die("data/ 目录没有写入权限");

require("../config.php");
require("../pdo.php");

$db = new Db();
$db->connect();
if(!$db->is_connected)
	die('db error');

$starttime = microtime(true);

include("admin.class.php");
$a = new admin($db);
echo $a->draw($_REQUEST);

$endtime = microtime(true);
printf("<!-- Page loaded in %f seconds -->", $endtime - $starttime);
die;
